import React from 'react';
import PostCard from './PostCard/PostCard';


const CardsWrapper = (props) => {
    return (

        <div></div>
    )
}

export default CardsWrapper;