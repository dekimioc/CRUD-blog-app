import placeholder from '../../../assets/imgs/placeholder100.png'

export const imgs = [
    {
        imageSrc: placeholder,
        altTag: "",
        key: 1
    },
    {
        imageSrc: placeholder,
        altTag: "",
        key: 2
    },
    {
        imageSrc: placeholder,
        altTag: "",
        key: 3
    }

]